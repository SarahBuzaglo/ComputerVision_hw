import pandas as pd
import os
import torch
import torch.utils.data
import torchvision
from PIL import Image
import cv2
import glob
import re
import numpy as np
import shutil

class ImageDataSet(torch.utils.data.Dataset):
    '''
    create a datset for segmentation by pre trained model (no label),
    the ImageDataSet class get *.jpg or *.png files
    '''
    def __init__(self,image_folder:str = 'my_data'):
            
        self.image_folder = image_folder
        self._FilterNonImages()
        self.transform_data = GetTransform_data()     
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")   

    def __getitem__(self, index , tensor_flag = True):
        x = Image.open(os.path.join(self.image_folder,self.images[index]))
        x = x.convert('RGB')
        if tensor_flag:
            x = self.transform_data(x)
            x = x.to(self.device)

        return x
        
    def __getstr__(self,name:str ,tensor_flag = True):
        x = Image.open(os.path.join(self.image_folder,name))
        x = x.convert('RGB')
        if tensor_flag:
            x = self.transform_data(x)
            x = x.to(self.device)

        return x

    def __getnumpy__(self, index ):
        x = cv2.imread(os.path.join(self.image_folder,self.images[index]))
        return x
    def __len__(self):
        return len(self.images)
    

    def _FilterNonImages(self):
        images = os.listdir(self.image_folder)
        self.images = [im for im in images if (im.find('.jpg') !=-1) or (im.find('.png') !=-1)]
        self.images = sortedAlphanumeric(self.images)



def GetTransform_data():
    '''
    get transformations
    ''' 
    custom_transforms = []
    
    # custom_transforms.append(torchvision.transforms.Resize(size=(224,224)))
    custom_transforms.append(torchvision.transforms.ToTensor())
    custom_transforms.append(torchvision.transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]))        
    return torchvision.transforms.Compose(custom_transforms)



def Unormalize(normalized_tensor):
    if len(normalized_tensor) == 4:
        normalized_tensor_ = normalized_tensor.squeeze(0)
    else:
        normalized_tensor_ = normalized_tensor
    mean_l = [0.485, 0.456, 0.406]
    std_l = [0.229, 0.224, 0.225]
    unorm_tensor = torch.zeros_like(normalized_tensor_)
    unorm_tensor[0,:,:] = std_l[0]*(normalized_tensor_) + mean_l[0]
    unorm_tensor[1,:,:] = std_l[1]*(normalized_tensor_) + mean_l[1]
    unorm_tensor[2,:,:] = std_l[2]*(normalized_tensor_) + mean_l[2]
    return unorm_tensor




def sortedAlphanumeric(data):
    '''
    sort a list of strings alphanumericly
    '''
    convert = lambda text: int(text) if text.isdigit() else text.lower()
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(data, key=alphanum_key)




def createDataloader(image_folder_train:str,batch_size=8,shuffle=True):
    '''
    creates a dataloader

    '''
    dataset_train = ImageDataSet(image_folder = image_folder_train) 

    data_loader_train = torch.utils.data.DataLoader(dataset_train, 
                                                    batch_size=batch_size,
                                                    shuffle=shuffle)

    return data_loader_train
