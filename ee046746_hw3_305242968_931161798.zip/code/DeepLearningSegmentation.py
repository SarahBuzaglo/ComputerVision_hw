import numpy as np 
import torch 
import torchvision as TV
import cv2
import glob
import os
import matplotlib.pyplot as plt
import torchvision.transforms as transforms
from PIL import Image
import torchvision.models as models
from torch.optim import lr_scheduler

def getClassifier():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # densenet161(pretrained=True)
    # resnet18(pretrained=True)
    # resnext50_32x4d(pretrained=True)
    # inception_v3(pretrained=True)
    return models.resnet18(pretrained=True).eval().to(device)

def classify(model , image):
    softmax = torch.nn.Softmax(dim=1)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    image = image.to(device)
    with torch.no_grad():
        if len(image.shape) == 3:
            return model(image.unsqueeze(0)).argmax(),softmax(model(image.unsqueeze(0)))
        return model(image).argmax(),softmax(model(image).unsqueeze(0))

def getDeepLabLabels():

    labels = ['aeroplane', 'bicycle', 'bird', 'boat', 'bottle',
            'bus', 'car', 'cat', 'chair', 'cow',
            'diningtable','dog', 'horse', 'motorbike', 'person',
            'pottedplant','sheep', 'sofa', 'train', 'tvmonitor']

    return labels 


# getModelDeepLabV3 , segmentImages , transformSegmentedToImg , -- segDataPrep

def getModelDeepLabV3():
    '''
    get DeepLabV3 pretrained model 
    '''
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    #model = torch.hub.load('pytorch/vision:v0.5.0', 'deeplabv3_resnet101', pretrained=True)
    model = torch.hub.load('pytorch/vision:v0.5.0', 'deeplabv3_resnet101', pretrained=True)
    model.to(device)
    return model.eval()




def segmentImages(input_tensor:torch.tensor,model):
    '''
    segment an image 
    '''
    model.eval()
    # define device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if len(input_tensor.shape) == 3:
        input_batch = input_tensor.unsqueeze(0) # create a mini-batch of size 1 as expected by the model
    else:
        input_batch = input_tensor
    # send to device
    input_batch = input_batch.to(device)    
    model = model.to(device)
    with torch.no_grad():
        output = model(input_batch)['out'][0]
        output_predictions = output.argmax(0)

    return output_predictions





def transformSegmentedToImg(output_predictions,input_image):
    '''
    get a segmentation model and return its a color representation
    '''
    palette = torch.tensor([2 ** 25 - 1, 2 ** 15 - 1, 2 ** 21 - 1])
    colors = torch.as_tensor([i for i in range(21)])[:, None] * palette
    colors = (colors % 255).numpy().astype("uint8")
    # plot the semantic segmentation predictions of 21 classes in each color
    r = Image.fromarray(output_predictions.byte().cpu().numpy()).resize(input_image.size)
    r.putpalette(colors)
    return r





def vlahos_alg(im,a1=1,a2=1):
    im_f = im.astype(np.float)/255
    alpha = 1-a1*(im_f[:,:,1] - a2*im_f[:,:,2])
    alpha[alpha<0] = 0
    alpha[alpha>1] = 1
    return alpha

