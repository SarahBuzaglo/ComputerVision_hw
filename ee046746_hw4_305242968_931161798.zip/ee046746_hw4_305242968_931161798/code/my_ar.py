import numpy as np
import matplotlib.pyplot as plt
import cv2
import scipy
from matplotlib import pyplot as plt
import my_homography as mh
#Add imports if needed:
import time
import os
#end imports

#Add functions here:
def imageStitchingMultiply(img1, warp_img2, offset_h, offset_w):
    """
    Input:
        im1         - colored image
        warp_img2   - colored image
        offset_h    - offset in height for the left image, using to keep it in the plane of tthe warped image
        offset_w    - offset in width for the left image using to keep it in the plane of tthe warped image
    Output:
        panoImg     - the output gathered panorama where img1 is to the left
    """
    # pad image1 with zeros
    h1, w1, _ = img1.shape
    panoImg = np.zeros(warp_img2.shape)
    # put image 1 to the left
    panoImg[-offset_h:h1-offset_h, -offset_w:w1-offset_w, :] = np.copy(img1)

    #panoImg = np.maximum(panoImg, warp_img2)
    ind = np.where(warp_img2 != 0)
    panoImg[ind] = warp_img2[ind]
    
 
    
    panoImg = panoImg.astype('uint8')
    return panoImg


#Functions end





# HW functions:
def create_ref(im_path_1,factor=0.25):
    # Read Images
    im = cv2.cvtColor(cv2.imread(im_path_1), cv2.COLOR_BGR2RGB)
    im = cv2.resize(im,None, fx=factor ,fy =factor,interpolation = cv2.INTER_LINEAR)
    im2 = np.zeros_like(im)
    H,W,_ = im.shape

    p1 = np.array([ [512,555,3535,3614] , [389,2349,241,2312] ])//4
    p2 = np.array([[0,0,H,H],[0,W,0,W]])

    h1to2 = mh.computeH(p2, p1)
    print(H,W)
    output_shape, offset_h, offset_w = mh.calculate_outsize_and_offset(im2,im, h1to2)
    
    warped_im2 = mh.warpH(im, np.linalg.inv(h1to2), output_shape, offset_h, offset_w)
    plt.imshow(warped_im2[330:849,385:780,:])
    plt.show()


    #panoImg = imageStitchingMultiply( im,warped_im2,offset_h, offset_w)
    #panoImg = panoImg[-offset_h:-offset_h+H , -offset_w:-offset_w+W,:]
    #print(output_shape,offset_h,offset_w)

    cv2.imwrite(os.path.join('my_data', 'ref_image.jpeg'), cv2.cvtColor(warped_im2[330:849,385:775,:], cv2.COLOR_RGB2BGR))
    return None #panoImg




def im2im(image, ref_image,stich_im):

    H_im,W_im,_ = image.shape
    H_ref,W_ref,_ = ref_image.shape
    H_stich,W_stich,_ = stich_im.shape
    ind_2 = np.where(stich_im == 0)
    stich_im[ind_2] = 3
    p1, p2 =mh.getPoints_SIFT(image, ref_image)

    h1to2 = mh.ransacH(p1.T, p2.T,nIter=5000, tol=1.5)
    output_shape, offset_h, offset_w = mh.calculate_outsize_and_offset(image,ref_image, h1to2)
    warped_im2 = mh.warpH(stich_im, h1to2, output_shape, offset_h, offset_w)

    panoImg = imageStitchingMultiply( im,warped_im2,offset_h, offset_w)
    panoImg = panoImg[-offset_h:-offset_h + H_im ,-offset_w:-offset_w + W_im ,:]
    plt.imshow(panoImg)
    plt.show()
    print(output_shape,offset_h,offset_w)

    cv2.imwrite(os.path.join('..', 'output', 'out_image.png'), cv2.cvtColor(panoImg, cv2.COLOR_RGB2BGR))
    return panoImg



if __name__ == '__main__':
    print('my_ar')

    im_path_obj = 'my_data//cover_img.jpeg'

    create_ref(im_path_obj)

    im_path_1 = "my_data//book.jpeg"
    #im_path_2 = "my_data//small_img.jpeg"
    im_path_2 = os.path.join('my_data', 'ref_image.jpeg')
    im_path_3 = "my_data//small_img_trump.jpeg"

    im = cv2.cvtColor(cv2.imread(im_path_1), cv2.COLOR_BGR2RGB)
    im = cv2.resize(im,None, fx=0.5 ,fy = 0.5,interpolation = cv2.INTER_LINEAR)

    ref_im = cv2.cvtColor(cv2.imread(im_path_2), cv2.COLOR_BGR2RGB)
    ref_im = cv2.resize(ref_im,None, fx=1 ,fy =1,interpolation = cv2.INTER_LINEAR)

    trump = cv2.cvtColor(cv2.imread(im_path_3), cv2.COLOR_BGR2RGB)
    trump = cv2.resize(trump, (ref_im.shape[1],ref_im.shape[0]) ,interpolation = cv2.INTER_LINEAR)

    #plt.imshow(trump)
    #plt.show()    

    im2im(im, ref_im,trump)