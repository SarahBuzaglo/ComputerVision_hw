import numpy as np
import matplotlib.pyplot as plt
import cv2
import scipy
from matplotlib import pyplot as plt
from scipy.interpolate import interp2d

#Add imports if needed:
import os
#end imports

#Add extra functions here:
def calculate_outsize_and_offset(im1, im2, H):
    """
      Input:
          im1           - colored image that is static in the panorama stitching
          im2           - colored image that is taking place in warping and then panorama stitching
          H             - homography matrix for projecting im2 to other image's plane
      Output:
          output_shape  -  the height and width of the panorama image of im1, im2
          offset_h      - offset in height for the images creating the panorama, using to keep their coordinates positive
          offset_w      - offset in width for the images creating the panorama, using to keep their coordinates positive
      """
    h1, w1 = im1.shape[:2]
    h2, w2 = im2.shape[:2]

    # coordinates of the corners of img2
    corner = np.array([[0, w2, 0, w2],
                       [0, 0, h2, h2],
                       [1, 1, 1, 1]])
    # find the new coordinates of the corners of img2 after warping
    warp_corner = H @ corner
    for i in range(3):
        warp_corner[i, :] /= warp_corner[-1, :]
    warp_corner = np.ceil(warp_corner)

    # calculate the maximum shape of the warped image
    max_h = max(np.max(warp_corner[1, :]), h1)
    min_h = min(np.min(warp_corner[1, :]), 0)
    max_w = max(np.max(warp_corner[0, :]), w1)
    min_w = min(np.min(warp_corner[0, :]), 0)

    # offset needed for both images:
    offset_w = int(min(min_w, 0))
    offset_h = int(min(min_h, 0))

    width = int(max_w) - offset_w
    height = int(max_h) - offset_h

    output_shape = (height, width)
    return output_shape, offset_h, offset_w


def first_nonzero(arr, axis=1, invalid_val=-1):
    mask = arr!=0
    return np.where(mask.any(axis=axis), mask.argmax(axis=axis), invalid_val)




def CreatePano(im1,im2,sift=True,ransac=True,left=True):
    p1, p2 =getPoints_SIFT(im1, im2)
    H= ransacH(p1.T,p2.T)
    #H_inv = np.linalg.inv(H)
    out_size, offset_h, offset_w = calculate_outsize_and_offset(cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY), cv2.cvtColor(im2, cv2.COLOR_BGR2GRAY), H)
    warped_im2 = warpH(im2, H, out_size, offset_h, offset_w)
    if left == True:

        warped_im2 = warpH(im2, H, out_size, offset_h, offset_w)
        panoImg = imageStitching( im1,warped_im2, offset_h, offset_w)
        return panoImg

    H_inv = np.linalg.inv(H)
    out_size, offset_h, offset_w = calculate_outsize_and_offset(cv2.cvtColor(im2, cv2.COLOR_BGR2GRAY), cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY), H_inv)
    warped_im1 = warpH(im1, H_inv, out_size, offset_h, offset_w)
    panoImg = imageStitching( im2,warped_im1, offset_h, offset_w)
    return panoImg


def CreateMnualPano(im1,im2,p1,p2,left=True):
    H = computeH(p1, p2)
    #H_inv = np.linalg.inv(H)
    out_size, offset_h, offset_w = calculate_outsize_and_offset(cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY), cv2.cvtColor(im2, cv2.COLOR_BGR2GRAY), H)
    warped_im2 = warpH(im2, H, out_size, offset_h, offset_w)
    if left == True:

        warped_im2 = warpH(im2, H, out_size, offset_h, offset_w)
        panoImg = imageStitching( im1,warped_im2, offset_h, offset_w)
        return panoImg

    H_inv = np.linalg.inv(H)
    out_size, offset_h, offset_w = calculate_outsize_and_offset(cv2.cvtColor(im2, cv2.COLOR_BGR2GRAY), cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY), H_inv)
    warped_im1 = warpH(im1, H_inv, out_size, offset_h, offset_w)
    panoImg = imageStitching( im2,warped_im1, offset_h, offset_w)
    return panoImg


def multiStitching(list_images):
    """assume that the list_images was supplied in left-to-right order, choose middle image then
    divide the array into 2 sub-arrays, left-array and right-array. Stiching middle image with each
    image in 2 sub-arrays. @param list_images is The list which containing images, @param smoothing_window is
    the value of smoothy side after stitched, @param output is the folder which containing stitched image
    """
    n = int(len(list_images)/2 +0.5)
    left = list_images[:n]
    right = list_images[n-1:]
    right.reverse()
    while len(left) >1:

        dst_img = left.pop()
        src_img = left.pop()
        left_pano = CreatePano(src_img,dst_img,sift=True,ransac=True,left=False)
        left.append(left_pano)
        #print(f'left:{len(left)}')
    #print('done left')
    #plt.figure()
    #plt.imshow(cv2.cvtColor(left_pano , cv2.COLOR_BGR2RGB))
    #plt.title('left panorama')
    #plt.show()
    while len(right) >1:

        dst_img = right.pop()
        src_img = right.pop()
        right_pano = CreatePano(src_img,dst_img,sift=True,ransac=True,left=True)
        right.append(right_pano)
    #plt.figure()
    #plt.imshow(cv2.cvtColor(right_pano , cv2.COLOR_BGR2RGB))
    #plt.title('right panorama')
    #plt.show()
    #print('done right')
    full_pano = CreatePano(left_pano, right_pano)
    return full_pano

#Extra functions end ---------------------------------------------------------------------------------------

# HW functions:
def getPoints(im1, im2, n_points=7):
    """
       Input:
       im1, im2 -  two 2D grayscale images
       n_points - number of corrosponding points you want to extract
       Output:
       p1,p2    - Each are size (2 x n_points) matrices of corresponding (x,y)' coordinates between two images
       """
    # get sizes
    # gray_im1 = cv2.cvtColor(im1, cv2.COLOR_RGB2GRAY)
    # gray_im2 = cv2.cvtColor(im2, cv2.COLOR_RGB2GRAY)
    h1, w1, _ = im1.shape
    h2, w2, _ = im2.shape

    
    # stitch images
    stitched_h = max(h1, h2)
    stitched_w = w1 + w2
    stitched = np.zeros((stitched_h, stitched_w, 3))
    stitched[:h1, :w1, :] = np.copy(im1)
    stitched[:h2, w1:, :] = np.copy(im2)

    # while invalid points: sample gui
    p1 = []
    p2 = []
    valid_points = False
    while not valid_points:
        total_p = []
        plt.figure()
        plt.title("Choose " + str(n_points) + " pairs of matching points."
                    "\n* select pair by pair"
                    "\n* left key to sample point"
                    "\n* right key to remove the most recently added point")
        plt.imshow(cv2.cvtColor(stitched.astype(np.uint8) , cv2.COLOR_BGR2RGB))

        plt.grid(False)
        plt.axis('off')

        total_p = plt.ginput(n=2*n_points, timeout=0)
        for (x, y) in total_p:
            if x < w1:
                p1.append((x, y))
                # p1.append((y, x))
            else:
                p2.append((x-w1, y))
                # p2.append((y, x - w1))

        if len(p1) == n_points and len(p2) == n_points:
            valid_points = True
        else:
            p1 = []
            p2 = []

    p1 = np.array(p1).T
    p2 = np.array(p2).T
    return np.uint64(p1), np.uint64(p2)  # TODO check np types


def computeH(p1, p2):
    """
      Input:
      p1 and p2 - Each are size (2 x N) matrices of corresponding (x,y)' coordinates between two images
      Output:
      H2to1 - matrix 3x3 encoding the homography that best matches the linear equation
    """
    assert (p1.shape[1] == p2.shape[1])
    assert (p1.shape[0] == 2)

    N = p1.shape[1]
    xi = p1[0, :].T
    yi = p1[1, :].T
    ui = p2[0, :].T
    vi = p2[1, :].T
    A = np.zeros((2*N,9))
    # build A
    #A1 = np.array([-1*ui.T, -1*vi.T, -1*np.ones(N), np.zeros(N), np.zeros(N), np.zeros(N), (xi*ui).T, (xi*vi).T, xi.T]).T
    #A2 = np.array([np.zeros(N), np.zeros(N), np.zeros(N), -1*ui.T, -1*vi.T, -1*np.ones(N), (yi*ui).T, (yi*vi).T, yi.T]).T
    #A = np.concatenate((A1, A2), axis=0)
    for ind in range(0,2*N,2):
        A[ind,:] = np.array([-1*ui[ind//2], -1*vi[ind//2], -1, 0, 0, 0, xi[ind//2]*ui[ind//2], xi[ind//2]*vi[ind//2], xi[ind//2]])
        A[ind+1,:] = np.array([0, 0, 0, -1*ui[ind//2], -1*vi[ind//2], -1, yi[ind//2]*ui[ind//2], yi[ind//2]*vi[ind//2], yi[ind//2]])
     # svd
    U, s, V_transposed = np.linalg.svd(A, full_matrices=True)
    V = np.transpose(V_transposed)

    # homogeneous solution of Ah=0 as the rightmost column vector of V.
    H = V[:,-1].reshape(3,3)

    # Normalize H by 1/h8.
    H /= V[:,-1][-1]

    return H

    D, V = np.linalg.eig(A.T @ A)
    id_min = np.argmin(D)
    H2to1 = V[:, id_min].reshape((3, 3))
    return H2to1

def warpH(im1, H, out_size,offset_h, offset_w):
    """
        inverse warping => for each pixel in im1:
        apply H^-1
        interpolate

        Input:
        im1         - colored image
        H           - matrix encoding the homography between im2 and im1
        out_size    - size of the output image
        offset_h    - offset in height for the warped image to keep its coordinates positive
        offset_w    - offset in width for the warped image to keep its coordinates positive
        Output:
        warp_im1    - transposed warp image im1 include empty background (zeros)
    """
    # im1 = cv2.cvtColor(im1, cv2.COLOR_RGB2LAB)
    channels = 1
    if im1.shape[-1] == 3:
        channels = 3
    invH = np.linalg.inv(H)
    warp_im1 = np.zeros((out_size[1], out_size[0], channels)).astype(int)
    x1 = np.arange(im1.shape[0]).astype(float)
    y1 = np.arange(im1.shape[1]).astype(float)

    for c in range(channels):
        f = interp2d(x1, y1, im1[:, :, c].T, kind='linear')
        for i in range(out_size[1]):
            for j in range(out_size[0]):
                coor_warped = np.array([i+offset_w, j+offset_h, 1])
                coor = invH @ coor_warped
                coor = coor / coor[-1]
                p, q = coor[0], coor[1]
                if 0 <= p < len(y1) and 0 <= q < len(x1):
                    warp_im1[i, j, c] = f(q, p)

    warped_im1 = warp_im1.astype('uint8')
    warped_im1 = np.transpose(warped_im1, (1, 0, 2))
    # warped_im1 = cv2.cvtColor(warped_im1, cv2.COLOR_LAB2RGB)
    return warped_im1


def imageStitching(img1, warp_img2, offset_h, offset_w):
    """
    Input:
        im1         - colored image
        warp_img2   - colored image
        offset_h    - offset in height for the left image, using to keep it in the plane of tthe warped image
        offset_w    - offset in width for the left image using to keep it in the plane of tthe warped image
    Output:
        panoImg     - the output gathered panorama where img1 is to the left
    """
    # pad image1 with zeros
    h1, w1, _ = img1.shape
    panoImg = np.zeros(warp_img2.shape)
    # put image 1 to the left
    panoImg[-offset_h:h1-offset_h, -offset_w:w1-offset_w, :] = np.copy(img1)

    panoImg = np.maximum(panoImg, warp_img2)
    panoImg = panoImg.astype('uint8')
    return panoImg



def ransacH(p1, p2, nIter=250, tol=1.5):
    p1 = np.array(p1).T
    p2 = np.array(p2).T
    num_points = p1.shape[1]
    max_p = -1
    bestH = np.zeros((3, 3))
    for i in range(nIter):
        try:
            indices = np.random.randint(low=0, high=num_points, size=4)
            points1 = p1[:, indices]
            #print(i)
            #print(points1)
            points2 = p2[:, indices]
            H = computeH(points1, points2)
            
            hp2 = np.dot(H, np.vstack((p2, np.ones((1, num_points)))))
            
            if (hp2[-1, :] < 1e-12).any():
                continue
            hp2 /= hp2[-1, :]
            hp2 = hp2[:-1, :]
            
            dist = np.sum((hp2 - p1)**2, axis=0) ** 0.5
            num = dist[dist <= tol].shape[0]
            
            if(num > max_p):
                bestH = H
                max_p = num
                #max_num_inlier_points = num
        except IndexError:
            print('Error')
    return bestH


def getPoints_SIFT(im1, im2):
    #cv2.cvtColor(panoImg , cv2.COLOR_BGR2RGB)
    
    FLANN_INDEX_KDTREE = 3
    #    orb = cv2.ORB_create(nfeatures=500, scoreType=cv2.ORB_FAST_SCORE)
    #   keypoints, descriptors = orb.detectAndCompute(image_data['img'], None)
    
    sift = cv2.xfeatures2d.SIFT_create()
    
    kp1, des1 = sift.detectAndCompute(im1, None)
    kp2, des2 = sift.detectAndCompute(im2, None)
    index = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
    search = dict(checks=50)
    flann = cv2.FlannBasedMatcher(index,search)
    matches = flann.knnMatch(des1, des2, k=2)
    mask = [[0, 0] for i in range(len(matches))]
    p1, p2 = [], []
    for i,(m,n) in enumerate(matches):
        if m.distance < 0.5*n.distance:
            mask[i] = [1, 0]
            p1.append(kp1[m.queryIdx].pt)
            p2.append(kp2[m.trainIdx].pt)
    draw_params = dict(matchColor = (0, 255, 0),
                   singlePointColor = (255, 0, 0),
                   matchesMask = mask,
                   flags = 0)
    #im3 = cv2.drawMatchesKnn(cv2.cvtColor(im1 , cv2.COLOR_BGR2RGB), kp1, cv2.cvtColor(im2 , cv2.COLOR_BGR2RGB), kp2, matches, None, **draw_params)
    #im3 = cv2.drawMatchesKnn(im1, kp1,im2,kp2, matches, None, **draw_params)
    #plt.imshow(im3)
    #plt.show()
    p1 = np.array(p1).T
    p2 = np.array(p2).T
    return np.uint64(p1), np.uint64(p2)




if __name__ == '__main__':
    print('my_homography')
    im1 = cv2.imread('data//incline_L.png')
    im2 = cv2.imread('data//incline_R.png')
    
    #p1, p2 = getPoints(im1, im2)
    #print(p1)
    #print(p2)
    p1 = np.array([[517.60420168, 703.15042017, 603.11680672, 520.83109244, 541.80588235,
        627.31848739, 383.68823529], [450.61932773, 516.77058824, 502.24957983, 171.49327731, 126.31680672, 255.39243697, 182.78739496]])
    p2 = np.array([[202.98235294, 394.98235294, 296.56218487, 198.14201681, 220.7302521,
        311.08319328,  40.02436975], [508.05798319, 559.68823529, 558.07478992, 220.86470588, 172.46134454, 306.37731092, 228.93193277]])
    
    H = computeH(p1, p2)
    H_inv = np.linalg.inv(H)
    out_size, offset_h, offset_w = calculate_outsize_and_offset(cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY), cv2.cvtColor(im2, cv2.COLOR_BGR2GRAY), H)
    print(out_size, offset_h, offset_w)
    
    warped_im2 = warpH(im2, H , out_size, offset_h, offset_w)
    panoImg = imageStitching( im1,warped_im2, offset_h, offset_w)
    cv2.imwrite(os.path.join('..', 'output', 'incline_pano_manual.png'), panoImg)


    p1, p2 =getPoints_SIFT(im1, im2)
    H= ransacH(p1.T,p2.T)
    panoImg = CreatePano(im1,im2,sift=True,ransac=True,left=True)
    panoImg =CreatePano(im1,im2,sift=True,ransac=True,left=False)
    plt.figure()
    plt.imshow(cv2.cvtColor(panoImg , cv2.COLOR_BGR2RGB))
    plt.show()
    cv2.imwrite(os.path.join('..', 'output', 'incline_pano_sift.png'), panoImg)
    #---------------------------------------------------------------------------------------------------

    #factor = 1
    #im1 = cv2.imread('my_data//7.jpg')
    #im1 = cv2.resize(im1, (int(im1.shape[0] // factor), int(im1.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im2 = cv2.imread('my_data//8.jpg')
    #im2 = cv2.resize(im2, (int(im2.shape[0] // factor), int(im2.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #
    #im3 = cv2.imread('my_data//9.jpg')
    #im3 = cv2.resize(im3, (int(im3.shape[0] // factor), int(im3.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im4 = cv2.imread('my_data//10.jpg')
    #im4 = cv2.resize(im4, (int(im4.shape[0] // factor), int(im4.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im5 = cv2.imread('my_data//11.jpg')
    #im5 = cv2.resize(im5, (int(im5.shape[0] // factor), int(im5.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    ##
    #img_list = [im1,im2,im3,im4,im5]
    #panoImg = multiStitching(img_list)
    #
    #mask_pano = np.where(panoImg !=0)
    #row = min(mask_pano[0])
    #cv2.imwrite(os.path.join('..', 'output', 'my_multi_pano.png'), panoImg[row:,:,:])
    #plt.figure()
    #plt.imshow(cv2.cvtColor(panoImg[row:,:,:] , cv2.COLOR_BGR2RGB))
    #plt.show()


    #factor = 1
    #im1 = cv2.imread('data//beach1.JPG')
    #im1 = cv2.resize(im1, (int(im1.shape[0] // factor), int(im1.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im2 = cv2.imread('data//beach2.JPG')
    #im2 = cv2.resize(im2, (int(im2.shape[0] // factor), int(im2.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im3 = cv2.imread('data//beach3.JPG')
    #im3 = cv2.resize(im3, (int(im3.shape[0] // factor), int(im3.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im4 = cv2.imread('data//beach4.JPG')
    #im4 = cv2.resize(im4, (int(im4.shape[0] // factor), int(im4.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im5 = cv2.imread('data//beach5.JPG')
    #im5 = cv2.resize(im5, (int(im5.shape[0] // factor), int(im5.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )

    #img_list = [im1,im2,im3,im4,im5]
    #panoImg = multiStitching(img_list)
    #
    #mask_pano = np.where(panoImg !=0)
    #row = min(mask_pano[0])
    #cv2.imwrite(os.path.join('..', 'output', 'beach_multi_pano.png'), panoImg[row:,:,:])
    #plt.figure()
    #plt.imshow(cv2.cvtColor(panoImg[row:,:,:] , cv2.COLOR_BGR2RGB))
    #plt.show()



    #factor = 6
    #im1 = cv2.imread('data//sintra1.JPG')
    #im1 = cv2.resize(im1, (int(im1.shape[0] // factor), int(im1.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im2 = cv2.imread('data//sintra2.JPG')
    #im2 = cv2.resize(im2, (int(im2.shape[0] // factor), int(im2.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im3 = cv2.imread('data//sintra3.JPG')
    #im3 = cv2.resize(im3, (int(im3.shape[0] // factor), int(im3.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im4 = cv2.imread('data//sintra4.JPG')
    #im4 = cv2.resize(im4, (int(im4.shape[0] // factor), int(im4.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )
    #im5 = cv2.imread('data//sintra5.JPG')
    #im5 = cv2.resize(im5, (int(im5.shape[0] // factor), int(im5.shape[1] // factor)),interpolation = cv2.INTER_LINEAR  )

    #img_list = [im1,im2,im3,im4,im5]
    #panoImg = multiStitching(img_list)
    #
    #mask_pano = np.where(panoImg !=0)
    #row = min(mask_pano[0])
    #cv2.imwrite(os.path.join('..', 'output', 'sintra_multi_pano.png'), panoImg[row:,:,:])
    #plt.figure()
    #plt.imshow(cv2.cvtColor(panoImg[row:,:,:] , cv2.COLOR_BGR2RGB))
    #plt.show()

